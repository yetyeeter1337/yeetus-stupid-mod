this mod is intended for use with mindustry by anuke build 126.2, this file is basiclly useless if not inserted into the mindustry mod folder as a .zip file

this is absolutely free (as in you don't have to pay for this ever) so if your paying for this then its not being distributed by the original owner
have fun :)